// 1. Panggil library yang dibutuhkan
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

// 2. Tentukan pin sesuai kabel di diagram.json kamu
#define PIN_DHT 15      // Kabel data DHT22 ada di pin 15
#define PIN_LED1 14     // LED 1 (hijau/normal) ada di pin 14
#define PIN_LED2 26     // LED 2 (merah/demam) ada di pin 26

// 3. Pengaturan sensor & layar OLED
DHT dht(PIN_DHT, DHT22);
Adafruit_SSD1306 oled(128, 64, &Wire, -1); // Ukuran layar 128x64

void setup() {
  // Menyalakan Serial Monitor (buat cek error di layar bawah)
  Serial.begin(115200);

  // Atur pin LED sebagai OUTPUT (mengeluarkan listrik)
  pinMode(PIN_LED1, OUTPUT);
  pinMode(PIN_LED2, OUTPUT);

  // Atur pin I2C sesuai kabelmu (SDA = 22, SCL = 21)
  Wire.begin(22, 21);

  // Nyalakan layar OLED (alamat 0x3C sesuai diagram.json)
  oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  oled.clearDisplay();
  oled.setTextColor(WHITE);

  // Nyalakan sensor DHT22
  dht.begin();
}

void loop() {
  // Baca suhu dari sensor
  float suhu = dht.readTemperature();

  // Cek apakah sensor terbaca
  if (isnan(suhu)) {
    Serial.println("Sensor error!");
    delay(1000);
    return;
  }

  // Logika cek suhu badan (normalnya 36.1 - 37.5 derajat Celcius)
  String status;
  if (suhu > 37.5) {
    status = "DEMAM!";
    digitalWrite(PIN_LED1, LOW);   // LED 1 mati
    digitalWrite(PIN_LED2, HIGH);  // LED 2 nyala (tanda bahaya)
  } else {
    status = "NORMAL";
    digitalWrite(PIN_LED1, HIGH);  // LED 1 nyala (aman)
    digitalWrite(PIN_LED2, LOW);   // LED 2 mati
  }

  // Tampilkan hasilnya ke layar OLED
  oled.clearDisplay();          // Bersihkan layar dulu
  oled.setTextSize(1);          // Ukuran huruf kecil
  oled.setCursor(0, 0);         // Posisi paling atas
  oled.println("Cek Suhu Badan:");

  oled.setTextSize(2);          // Ukuran huruf besar buat angka suhu
  oled.setCursor(0, 20);        // Posisi agak ke tengah
  oled.print(suhu);
  oled.println(" C");

  oled.setTextSize(1);          // Ukuran huruf kecil lagi buat status
  oled.setCursor(0, 48);        // Posisi bawah
  oled.print("Status: ");
  oled.println(status);

  oled.display();               // Munculkan semua tulisan ke layar!

  // Tunggu 2 detik sebelum baca ulang
  delay(2000);
}