#include "DHT.h"

#define DHTPIN 4
#define DHTTYPE DHT22
#define LED_PIN 2
#define BUZZER_PIN 15

DHT dht(DHTPIN, DHTTYPE);

const float TEMP_THRESHOLD = 30.0;
const float HUM_THRESHOLD = 70.0;

void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  Serial.println("System Monitoring Suhu Server Started...");
}

void loop() {
  delay(2000);

  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("Gagal membaca dari sensor DHT!");
    return;
  }

  Serial.print("Suhu: "); 
  Serial.print(temp); 
  Serial.print(" °C | ");
  Serial.print("Kelembapan: "); 
  Serial.print(hum); 
  Serial.println(" %");

  if (temp > TEMP_THRESHOLD || hum > HUM_THRESHOLD) {
    digitalWrite(LED_PIN, HIGH);
    tone(BUZZER_PIN, 1000);
    Serial.println(">>> WARNING: Kondisi Ruangan Abnormal! <<<");
  } else {
    digitalWrite(LED_PIN, LOW);
    noTone(BUZZER_PIN);
  }
}