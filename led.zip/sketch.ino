const int ledmerah = 13;
const int ledkuning = 0;
const int ledhijau = 4;



void setup() {
 pinMode(ledmerah, OUTPUT);
 pinMode(ledkuning, OUTPUT);
 pinMode(ledhijau, OUTPUT);
}

void loop() {
  digitalWrite(ledmerah,HIGH);
  digitalWrite(ledkuning, LOW);
 digitalWrite(ledhijau, LOW);
  delay(1000);

  digitalWrite(ledmerah,LOW);
  digitalWrite(ledkuning, HIGH);
digitalWrite(ledhijau, LOW);
  delay(1000);

  digitalWrite(ledmerah,LOW);
  digitalWrite(ledkuning, LOW);
digitalWrite(ledhijau, HIGH);
  delay(1000);
}
